-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: gms_admin
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `gms_admin`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `gms_admin` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `gms_admin`;

--
-- Table structure for table `mcompany`
--

DROP TABLE IF EXISTS `mcompany`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mcompany` (
  `pkCompID` varchar(10) NOT NULL COMMENT 'Short code  e.g. ADS, TEST',
  `fkGroupID` varchar(10) NOT NULL,
  `CompName` varchar(30) NOT NULL,
  `CompAlias` varchar(15) NOT NULL,
  `dbName` varchar(50) NOT NULL COMMENT 'MySQL DB name  e.g. gms_ads',
  `IsPrimary` varchar(2) NOT NULL DEFAULT 'N' COMMENT 'Y = Primary; can write shared masters',
  `Active` varchar(2) NOT NULL DEFAULT 'Y',
  `fkUserID` varchar(100) NOT NULL,
  `CrMod` datetime NOT NULL,
  PRIMARY KEY (`pkCompID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mcompany`
--

LOCK TABLES `mcompany` WRITE;
/*!40000 ALTER TABLE `mcompany` DISABLE KEYS */;
INSERT INTO `mcompany` VALUES ('ADS','BHW','Aditya Services','ADS','gms_ads','Y','Y','SYSTEM','2026-06-24 13:32:51'),('TEST','BHW','TEST','TEST','gms_test','N','Y','SYSTEM','2026-06-24 13:32:51'),('TEST1','VLCO','TEST1','TEST1','gms_test1','N','Y','SYSTEM','2026-06-24 13:32:51'),('VLCO','VLCO','Velji Lukhamsi & Co','VLCO','gms_vlco','Y','Y','SYSTEM','2026-06-24 13:32:51');
/*!40000 ALTER TABLE `mcompany` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mcompanygroup`
--

DROP TABLE IF EXISTS `mcompanygroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mcompanygroup` (
  `pkGroupID` varchar(10) NOT NULL COMMENT 'Short code  e.g. BHW, VLCO',
  `GroupName` varchar(50) NOT NULL,
  `Active` varchar(2) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`pkGroupID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mcompanygroup`
--

LOCK TABLES `mcompanygroup` WRITE;
/*!40000 ALTER TABLE `mcompanygroup` DISABLE KEYS */;
INSERT INTO `mcompanygroup` VALUES ('BHW','Bhiwandi','Y'),('VLCO','Velji Lukhamsi & Co','Y');
/*!40000 ALTER TABLE `mcompanygroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mpermission`
--

DROP TABLE IF EXISTS `mpermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mpermission` (
  `fkRoleID` varchar(20) NOT NULL,
  `ModuleCode` varchar(30) NOT NULL,
  `CanView` varchar(2) NOT NULL DEFAULT 'N',
  `CanAdd` varchar(2) NOT NULL DEFAULT 'N',
  `CanEdit` varchar(2) NOT NULL DEFAULT 'N',
  `CanDelete` varchar(2) NOT NULL DEFAULT 'N',
  `CanPrint` varchar(2) NOT NULL DEFAULT 'N',
  `CanExport` varchar(2) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`fkRoleID`,`ModuleCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mpermission`
--

LOCK TABLES `mpermission` WRITE;
/*!40000 ALTER TABLE `mpermission` DISABLE KEYS */;
INSERT INTO `mpermission` VALUES ('BHW_ADMIN','ADMIN','Y','Y','Y','Y','Y','Y'),('BHW_ADMIN','ARRIVAL','Y','Y','Y','Y','Y','Y'),('BHW_ADMIN','ATTENDANCE','Y','Y','Y','Y','Y','Y'),('BHW_ADMIN','AUDIT_REP','Y','Y','Y','Y','Y','Y'),('BHW_ADMIN','BAL_REP','Y','Y','Y','Y','Y','Y'),('BHW_ADMIN','BILL_LETTER','Y','Y','Y','Y','Y','Y'),('BHW_ADMIN','BILLING','Y','Y','Y','Y','Y','Y'),('BHW_ADMIN','DELIVERY','Y','Y','Y','Y','Y','Y'),('BHW_ADMIN','DISPATCH','Y','Y','Y','Y','Y','Y'),('BHW_ADMIN','DOCUMENTS','Y','Y','Y','Y','Y','Y'),('BHW_ADMIN','HAMALI','Y','Y','Y','Y','Y','Y'),('BHW_ADMIN','HAMALI_REP','Y','Y','Y','Y','Y','Y'),('BHW_ADMIN','ITEM_MASTER','Y','Y','Y','Y','Y','Y'),('BHW_ADMIN','MASTERS','Y','Y','Y','Y','Y','Y'),('BHW_ADMIN','MOD_RATE','Y','Y','Y','Y','Y','Y'),('BHW_ADMIN','PARTY','Y','Y','Y','Y','Y','Y'),('BHW_ADMIN','RECEIPTS','Y','Y','Y','Y','Y','Y'),('BHW_ADMIN','REPORTS','Y','Y','Y','Y','Y','Y'),('BHW_ADMIN','TRF_DB','Y','Y','Y','Y','Y','Y'),('BHW_ADMIN','TRF_OPN_BAL','Y','Y','Y','Y','Y','Y'),('BHW_ADMIN','UP_SERIAL_NUM','Y','Y','Y','Y','Y','Y'),('BHW_USER','ADMIN','N','N','N','N','N','N'),('BHW_USER','ARRIVAL','Y','Y','Y','N','Y','Y'),('BHW_USER','ATTENDANCE','Y','N','N','N','N','N'),('BHW_USER','BILLING','Y','Y','Y','N','Y','Y'),('BHW_USER','DELIVERY','Y','Y','Y','N','Y','Y'),('BHW_USER','DISPATCH','Y','Y','Y','N','Y','N'),('BHW_USER','ITEM_MASTER','N','N','N','N','N','N'),('BHW_USER','MASTERS','N','N','N','N','N','N'),('BHW_USER','PARTY','N','N','N','N','N','N'),('BHW_USER','REPORTS','Y','N','N','N','Y','N'),('VLCO_ADMIN','ADMIN','Y','Y','Y','Y','Y','Y'),('VLCO_ADMIN','ARRIVAL','Y','Y','Y','Y','Y','Y'),('VLCO_ADMIN','ATTENDANCE','Y','Y','Y','Y','Y','Y'),('VLCO_ADMIN','AUDIT_REP','Y','Y','Y','Y','Y','Y'),('VLCO_ADMIN','BAL_REP','Y','Y','Y','Y','Y','Y'),('VLCO_ADMIN','BILL_LETTER','Y','Y','Y','Y','Y','Y'),('VLCO_ADMIN','BILLING','Y','Y','Y','Y','Y','Y'),('VLCO_ADMIN','DELIVERY','Y','Y','Y','Y','Y','Y'),('VLCO_ADMIN','DISPATCH','Y','Y','Y','Y','Y','Y'),('VLCO_ADMIN','HAMALI','Y','Y','Y','Y','Y','Y'),('VLCO_ADMIN','HAMALI_REP','Y','Y','Y','Y','Y','Y'),('VLCO_ADMIN','ITEM_MASTER','Y','Y','Y','Y','Y','Y'),('VLCO_ADMIN','MASTERS','Y','Y','Y','Y','Y','Y'),('VLCO_ADMIN','MOD_RATE','Y','Y','Y','Y','Y','Y'),('VLCO_ADMIN','PARTY','Y','Y','Y','Y','Y','Y'),('VLCO_ADMIN','RECEIPTS','Y','Y','Y','Y','Y','Y'),('VLCO_ADMIN','REPORTS','Y','Y','Y','Y','Y','Y'),('VLCO_ADMIN','TRF_DB','Y','Y','Y','Y','Y','Y'),('VLCO_ADMIN','TRF_OPN_BAL','Y','Y','Y','Y','Y','Y'),('VLCO_USER','ADMIN','N','N','N','N','N','N'),('VLCO_USER','ARRIVAL','Y','Y','Y','N','Y','Y'),('VLCO_USER','BILLING','Y','Y','Y','N','Y','Y'),('VLCO_USER','DELIVERY','Y','Y','Y','N','Y','Y'),('VLCO_USER','DISPATCH','Y','Y','Y','N','Y','N'),('VLCO_USER','MASTERS','Y','N','N','N','N','N'),('VLCO_USER','REPORTS','Y','N','N','N','Y','Y');
/*!40000 ALTER TABLE `mpermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mrole`
--

DROP TABLE IF EXISTS `mrole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mrole` (
  `pkRoleID` varchar(20) NOT NULL COMMENT 'e.g. BHW_ADMIN, VLCO_USER',
  `fkGroupID` varchar(10) NOT NULL,
  `RoleName` varchar(50) NOT NULL,
  `Active` varchar(2) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`pkRoleID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mrole`
--

LOCK TABLES `mrole` WRITE;
/*!40000 ALTER TABLE `mrole` DISABLE KEYS */;
INSERT INTO `mrole` VALUES ('BHW_ADMIN','BHW','Administrator','Y'),('BHW_USER','BHW','Regular User','Y'),('VLCO_ADMIN','VLCO','Administrator','Y'),('VLCO_USER','VLCO','Regular User','Y');
/*!40000 ALTER TABLE `mrole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `muser`
--

DROP TABLE IF EXISTS `muser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `muser` (
  `pkUserId` varchar(100) NOT NULL COMMENT 'UUID',
  `fkGroupID` varchar(10) NOT NULL,
  `fkBranchID` varchar(10) NOT NULL DEFAULT 'HO',
  `UserCode` varchar(10) NOT NULL,
  `UserFullName` varchar(30) NOT NULL,
  `UserPassword` varchar(255) NOT NULL COMMENT 'bcrypt hash',
  `fkRoleID` varchar(20) NOT NULL DEFAULT 'ADMIN',
  `Active` varchar(2) NOT NULL DEFAULT 'Y',
  `CrMod` datetime NOT NULL,
  PRIMARY KEY (`pkUserId`),
  UNIQUE KEY `uq_user_group_code` (`fkGroupID`,`UserCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `muser`
--

LOCK TABLES `muser` WRITE;
/*!40000 ALTER TABLE `muser` DISABLE KEYS */;
INSERT INTO `muser` VALUES ('ADMIN','BHW','HO','ADMIN','Administrator','$2b$10$TELVbLF72sBTceExNxo0IehYeUbO6xmxm9BjRuxofHgClryZpXrJu','BHW_ADMIN','Y','2026-06-24 13:36:39'),('VLCO','VLCO','HO','ADMIN','Administrator','$2b$10$TELVbLF72sBTceExNxo0IehYeUbO6xmxm9BjRuxofHgClryZpXrJu','VLCO_ADMIN','Y','2026-06-24 13:36:39');
/*!40000 ALTER TABLE `muser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'gms_admin'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-10 14:46:09
